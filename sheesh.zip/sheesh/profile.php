<?php include('partials/header.php');
include('./classes/Profile.php');
$Profile = new Recipe();
$id = $_GET['id'];
$profile = $Profile->viewProfile($id);

?>
            <p>Title:<?php echo $profile['title'];?></p>
            <p>Meal:<?php echo $profile['meal'];?></p>
            <p>Cuisine:<?php echo $profile['cuisine'];?></p>
            <p>Difficulty:<?php echo $profile['difficulty'];?></p>
            <p>Ingredients:<?php echo $profile['ingredients'];?></p>
            <p>Instructions:<?php echo $profile['instructions'];?></p>
        <p>
            <a href="view.php">View all</a>
        </p>
</table>
<?php include('partials/footer.php'); ?>