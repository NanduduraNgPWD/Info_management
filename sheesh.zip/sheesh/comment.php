<?php
include('partials/header.php');
include('classes/Profile.php');
$profile = new Recipe();

if(isset($_REQUEST['btn'])){
    $profile->addProfile($_REQUEST);
}
    #$fname = $_REQUEST['fname'];
    #$lname = $_REQUEST['lname'];
    #$date = date("m-d-Y" , strtotime($_REQUEST['date']));
    #$name = $fname . " " . $lname;
    #echo $name;
    #echo $date;
    
?>
<section class="dashboard">
    <div class="left">
            <div class="title">
            <img src="images/menu.png" alt="">
            <h1>RecipeShare</h1>
            </div>
        <div class="left-content">
           <div class="menu">
           <a href="recipe.php">
            <div class="menu" id="link">
            <img class="icon" src="images/recipe.png" alt="">
            <p>Recipe</p>
            </div>
            </a>
           </div>
            <div class="menu">
            <a href="search.php">
            <div class="Search" id="link">
            <img class="icon"src="images/search.png" alt="">
            <p>Search</p>
            </div>
            </a>
            </div>
            <div class="menu" id="menu">
            <a href="comment.php">
            <div class="Comment" id="link">
            <img class="icon" src="images/comment.png" alt="">
            <p>Comment</p>
            </div>
            </a>
            </div>
            <div class="menu">
            <a href="user.php">
            <div class="User" id="link">
            <img class="icon" src="images/user.png" alt="">
            <p>User</p>
            </div>
            </a>
            </div>
        </div>
    </div>
    <div class="right">
        <form>
            <label for="author">Author ID:</label>
            <input type="text" id="author" name="author" required>

            <label for="recipe_name">Recipe/Post ID:</label>
            <input type="text" required>

            <label for="recipe_name">Subject:</label>
            <input type="text" required>

            <label for="ingredients">Comment:</label>
            <textarea id="ingredients" name="ingredients" rows="4" cols="50" required></textarea>

            <label for="recipe_name">Add image (optional):</label>
            <input type="file" name="image" accept="image/*">

            <label for="recipe_name">Date posted:</label>
            <input type="date" id="datePosted" name="date">

            <input type="submit" value="Submit">
           
        </form>
    </div>
</section>
</body>
<style>
    #menu{
        background-color: #00ADB5!important;
    }
</style>

</html>