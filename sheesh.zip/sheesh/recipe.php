<?php
include('partials/header.php');
include('classes/Profile.php');
$profile = new Recipe();

if(isset($_REQUEST['btn'])){
    $profile->addProfile($_REQUEST);
}
    #$fname = $_REQUEST['fname'];
    #$lname = $_REQUEST['lname'];
    #$date = date("m-d-Y" , strtotime($_REQUEST['date']));
    #$name = $fname . " " . $lname;
    #echo $name;
    #echo $date;
    
?>
<section class="dashboard">
    <div class="left">
            <div class="title">
            <img src="images/menu.png" alt="">
            <h1>RecipeShare</h1>
            </div>
        <div class="left-content">
           <div class="menu" id="menu">
           <a href="recipe.php">
            <div class="menu" id="link">
            <img class="icon" src="images/recipe.png" alt="">
            <p>Recipe</p>
            </div>
            </a>
           </div>
            <div class="menu">
            <a href="search.php">
            <div class="Search" id="link">
            <img class="icon"src="images/search.png" alt="">
            <p>Search</p>
            </div>
            </a>
            </div>
            <div class="menu">
            <a href="comment.php">
            <div class="Comment" id="link">
            <img class="icon" src="images/comment.png" alt="">
            <p>Comment</p>
            </div>
            </a>
            </div>
            <div class="menu">
            <a href="user.php">
            <div class="User" id="link">
            <img class="icon" src="images/user.png" alt="">
            <p>User</p>
            </div>
            </a>
            </div>
        </div>
    </div>
    <div class="right">
        <form>
            <label for="recipe_name">Recipe Name:</label>
            <input type="text" name="title" required>
           
            
            <label for="meal_type">Meal type:</label>
            <input type="text" name="meal" required>
            

            <label for="cuisine_type">Cuisine type:</label>
            <input type="text" name="cuisine" required>
            

            <label for="difficulty">Difficulty:</label>
            <input type="text" name="difficulty" required>

            <label for="ingredients">Ingredients:</label>
            <textarea id="ingredients" name="ingredients" rows="4" cols="50" required></textarea>

            <label for="instructions">Instructions:</label>
            <textarea id="instructions" name="instructions" rows="4" cols="50" required></textarea>
            <input type="submit" value="Submit"  name="btn">
            <a href="view.php">View all</a>
        </form>
    </div>
</section>
</body>
<style>
    #menu{
        background-color: #00ADB5!important;
    }
</style>
</html>