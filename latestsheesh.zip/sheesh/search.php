<?php
include('partials/header.php');
include('classes/Profile.php');
$profile = new Recipe();

if(isset($_REQUEST['btn'])){
    $profile->addProfile($_REQUEST);
}
    #$fname = $_REQUEST['fname'];
    #$lname = $_REQUEST['lname'];
    #$date = date("m-d-Y" , strtotime($_REQUEST['date']));
    #$name = $fname . " " . $lname;
    #echo $name;
    #echo $date;
    
?>
<section class="dashboard">
    <div class="left">
            <div class="title">
            <img src="images/menu.png" alt="">
            <h1>RecipeShare</h1>
            </div>
        <div class="left-content">
           <div class="menu">
           <a href="recipe.php">
            <div class="menu" id="link">
            <img class="icon" src="images/recipe.png" alt="">
            <p>Recipe</p>
            </div>
            </a>
           </div>
           <div class="menu">
            <a href="view.php">
            <div class="Comment" id="link">
            <img class="icon" src="images/comment.png" alt="">
            <p>View</p>
            </div>
            </a>
            </div>
            <div class="menu" id="menu">
            <a href="search.php">
            <div class="Search" id="link">
            <img class="icon"src="images/search.png" alt="">
            <p>Search</p>
            </div>
            </a>
            </div>
            <div class="menu">
            <a href="comment.php">
            <div class="Comment" id="link">
            <img class="icon" src="images/comment.png" alt="">
            <p>Comment</p>
            </div>
            </a>
            </div>
            <div class="menu">
            <a href="user.php">
            <div class="User" id="link">
            <img class="icon" src="images/user.png" alt="">
            <p>User</p>
            </div>
            </a>
            </div>
        </div>
    </div>
    <div class="right">
    <form>
            <label for="keyword">Keyword:</label>
            <input type="text" required>
            
                <div class="form-body">
                <div class="form-group">
                <label for="meal_type">Meal type:</label>
                <div class="form-item">
                <input type="checkbox" id="breakfast" name="meal_type" value="breakfast">
                <label for="breakfast">Breakfast</label>
                </div>
                <div class="form-item">
                <input type="checkbox" id="lunch" name="meal_type" value="lunch">
                <label for="lunch">Lunch</label>
                </div>
                <div class="form-item">
                <input type="checkbox" id="dinner" name="meal_type" value="dinner">
                <label for="dinner">Dinner</label>
                </div>
                </div>
            
                <div class="form-group">
                <label for="cuisine_type">Cuisine type:</label>
                <div class="form-item">
                <input type="checkbox" id="asian" name="cuisine_type" value="asian">
                <label for="asian">Asian</label>
                </div>
                <div class="form-item">
                <input type="checkbox" id="western" name="cuisine_type" value="western">
                <label for="western">Western</label>
                </div>
                <div class="form-item">
                <input type="checkbox" id="others" name="cuisine_type" value="others">
                <label for="others">Others</label>
                </div>
                </div>

                <div class="form-group">
                <label for="difficulty">Difficulty:</label>
                <div class="form-item">
                <input type="checkbox" id="easy" name="difficulty" value="easy">
                <label for="easy">Easy</label>
                </div>
                <div class="form-item">
                <input type="checkbox" id="medium" name="difficulty" value="medium">
                <label for="medium">Medium</label>
                </div>
                <div class="form-item">
                <input type="checkbox" id="hard" name="difficulty" value="hard">
                <label for="hard">Hard</label>
                </div>
                </div>
                <div class="form-group" id="date">
                <label for="fromYear">From:</label>
                <select id="fromYear" name="fromYear">
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
                    <option value="2022">2022</option>
                    
                </select>
                
                <label for="toYear">To:</label>
                <select id="toYear" name="toYear">
                    <option value="2022">2022</option>
                    <option value="2023">2023</option>
                    <option value="2024">2024</option>
                    
                </select>
                </div>
                </div>
            <input type="submit" value="Submit">
        </form>
    </div>
</section>
</body>
<style>
    #menu{
        background-color: #00ADB5!important;
    }
    label{
        display: inline;
    }
    form{
        height: 45vh;
        
    }
</style>
</html>