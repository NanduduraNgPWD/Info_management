<?php

class Recipe {
    function addProfile($req){
        global $con;
        $title = $req['title'];
        $meal = $req['meal'];
        $cuisine = $req['cuisine'];
        $difficulty = $req['difficulty'];
        $ingredients = $req['ingredients'];
        $instructions = $req['instructions'];

            try {
            $sql = "INSERT INTO `tbl_recipe`
            VALUES (0,'$title','$meal','$cuisine' , '$difficulty', '$ingredients' , '$instructions',1)";
                $con->exec($sql);
                echo '<script>window.location.href = "recipe.php";</script>';
            }
        catch(PDOException $e){
            echo $sql . "<br>" . $e->getMessage();
        }
    }
    function displayProfiles(){
        global $con;
        $sql = "SELECT * FROM `tbl_recipe` ORDER BY id ";
        $stmt = $con->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_BOTH);
    }
    function viewProfile($id = 0){
        global $con;
        $sql = "SELECT * FROM tbl_recipe WHERE id = $id";
        
        $stmt = $con->prepare($sql);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_BOTH);
    }
    function deleteProfile($id = 0){
        global $con;
        $sql = "DELETE FROM `tbl_recipe` WHERE id = $id";
        
        $stmt = $con->prepare($sql);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_BOTH);
    }
    function updateProfile(){
        
        global $con;
        if (isset($_POST['btn'])) {
            $title = $_POST['title'];
            $meal = $_POST['meal'];
            $cuisine = $_POST['cuisine'];
            $difficulty = $_POST['difficulty'];
            $ingredients = $_POST['ingredients'];
            $instructions = $_POST['instructions'];
        
            try {
                $pdo = new PDO('mysql:host=localhost;dbname=db_forms', 'root', '');
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
                $sql = "UPDATE `tbl_recipe` SET title=:title, meal=:meal, cuisine=:cuisine, difficulty=:difficulty, ingredients=:ingredients, instructions=:instructions WHERE id=:id";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':title', $title);
                $stmt->bindParam(':meal', $meal);
                $stmt->bindParam(':cuisine', $cuisine);
                $stmt->bindParam(':difficulty', $difficulty);
                $stmt->bindParam(':ingredients', $ingredients);
                $stmt->bindParam(':instructions', $instructions);
                $stmt->bindParam(':id', $id);
                $stmt->execute();
        
                echo "updated na!";
            } catch (PDOException $e) {
                echo "Error: " . $e->getMessage();
            }
        }
    }
}


?>