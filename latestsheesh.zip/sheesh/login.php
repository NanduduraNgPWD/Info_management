<?php
include('partials/header.php');
include('classes/Profile.php');
$profile = new Recipe();

if(isset($_REQUEST['btn'])){
    $profile->addProfile($_REQUEST);
}
    #$fname = $_REQUEST['fname'];
    #$lname = $_REQUEST['lname'];
    #$date = date("m-d-Y" , strtotime($_REQUEST['date']));
    #$name = $fname . " " . $lname;
    #echo $name;
    #echo $date;
    
?>
<form id="loginForm">
    <div class="img"> <img src="images/key.png" alt="">
    </div>
        <input type="text" id="username" placeholder="Username" required>
        
        <input type="password" id="password" placeholder="Password" required>
        
        <a href="index.php"><input type="submit" id="submit" value="Submit"></a>
    </form>
</body>
</html>