<?php
include('partials/header.php');
include('classes/Profile.php');
$profile = new Recipe();
echo $_GET['updateid'];
$id = $_GET['updateid'];

?>
   <div class="right">
        <form action='' method='POST' name='frmReg'>
            <label for="recipe_name">Recipe Name:</label>
            <input type="text" name="title" required>
           
            
            <label for="meal_type">Meal type:</label>
            <input type="text" name="meal" required>
            

            <label for="cuisine_type">Cuisine type:</label>
            <input type="text" name="cuisine" required>
            

            <label for="difficulty">Difficulty:</label>
            <input type="text" name="difficulty" required>

            <label for="ingredients">Ingredients:</label>
            <textarea id="ingredients" name="ingredients" rows="4" cols="50" required></textarea>

            <label for="instructions">Instructions:</label>
            <textarea id="instructions" name="instructions" rows="4" cols="50" required></textarea>
            <input type="submit" value="Update"  name="btn">
            <a href="view.php">View all</a>
        </form>
    </div>
<?php
include('partials/footer.php');
?>
