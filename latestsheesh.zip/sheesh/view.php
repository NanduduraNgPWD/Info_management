<?php include('partials/header.php');
include('./classes/Profile.php');
$Profile = new Recipe();
$profiles = $Profile->displayProfiles();
if(isset($_REQUEST['delid'])){
    $did = $_REQUEST['delid'];
   $Profile->deleteProfile($did); ?>
    <script>
        confirm("r u sure?")
    </script>
    <?php

    }

?>
<section class="dashboard">
    <div class="left">
            <div class="title">
            <img src="images/menu.png" alt="">
            <h1>RecipeShare</h1>
            </div>
        <div class="left-content">
           <div class="menu">
           <a href="recipe.php">
            <div class="menu" id="link">
            <img class="icon" src="images/recipe.png" alt="">
            <p>Recipe</p>
            </div>
            </a>
           </div>
           <div class="menu">
            <a href="view.php">
            <div class="Comment" id="link">
            <img class="icon" src="images/comment.png" alt="">
            <p>View</p>
            </div>
            </a>
            </div>
            <div class="menu">
            <a href="recipe.php">
            <div class="Search" id="link">
            <img class="icon"src="images/search.png" alt="">
            <p>Search</p>
            </div>
            </a>
            </div>
            <div class="menu">
            <a href="comment.php">
            <div class="Comment" id="link">
            <img class="icon" src="images/comment.png" alt="">
            <p>Comment</p>
            </div>
            </a>
            </div>
            <div class="menu">
            <a href="user.php">
            <div class="User" id="link">
            <img class="icon" src="images/user.png" alt="">
            <p>User</p>
            </div>
            </a>
            </div>
        </div>
    </div>
    <div class="right">
    <table border = '1' cellpadding="5">
    <tr>
    <th>ID</th>
    <th>Title</th>
    <th>Meal type</th>
    <th>Cuisine type</th>
    <th>Difficulty</th>
    <th>Ingredients </th>
    <th>Instructions </th>
    <th>Actions </th>
    </tr>

        <?php foreach($profiles as $prof){ ?>
        <tr>
            <td><?php echo $prof['id'];?></td>
            <td>
<a href = "profile.php?id=<?php echo $prof['id']; ?>"><?php echo $prof['title'];?> </a>
            </td>
            <td><?php echo $prof['meal'];?></td>
            <td><?php echo $prof['cuisine'];?></td>
            <td><?php echo $prof['difficulty'];?></td>
            <td><?php echo $prof['ingredients'];?></td>
            <td><?php echo $prof['instructions'];?></td>
            <td>
            <img src ='images/view.jpg' width = '16' >
            <a href="update.php?updateid=<?php echo $prof['id']; ?>"><img src="images/edit.png" width="16"></a>
                <a href= "view.php?delid=<?php echo $prof['id']; ?>"><img src ='images/delete.jpg' width = '16' ></a>
        
            </td>
        </tr>
    
         <?php } ?>


</table>
    </div>
</section>
<?php include('partials/footer.php'); ?>