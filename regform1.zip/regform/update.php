<?php
include('partials/header.php');
include('classes/Profile.php');
$profile = new Profile();
echo $_GET['updateid'];
$id = $_GET['updateid'];

if (isset($_POST['btn'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $date = date("Y-m-d", strtotime($_POST['date']));
    $address = $_POST['address'];

    try {
        $pdo = new PDO('mysql:host=localhost;dbname=db_app', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "UPDATE `tbl_profile` SET fname=:fname, lname=:lname, date=:date, address=:address WHERE id=:id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':fname', $fname);
        $stmt->bindParam(':lname', $lname);
        $stmt->bindParam(':date', $date);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        echo "updated na!";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
<form action='' method='POST' name='frmReg'>
    <label>First name:</label>
    <input type="text" name="fname"><br>

    <label>Last name:</label>
    <input type="text" name="lname"><br>

    <label>Birthday:</label>
    <input type="date" name="date"><br>

    <label>Address:</label><br>
    <textarea name="address" id="" cols="30" rows="10"></textarea><br>

    <input type="submit" value="Update" name="btn">
</form>
<a href="view.php">View all</a>
<?php
include('partials/footer.php');
?>
