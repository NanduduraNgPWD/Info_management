<?php
include('./classes/Database.php');
global $DB;
global $con;
$DB = new Database();
$DB->connectDB();
?>

<html>
    <title>
        hello
    </title>
    <body>