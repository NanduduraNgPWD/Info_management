<?php

class Profile {
    function addProfile($req){
        global $con;
        $fname = $req['fname'];
        $lname = $req['lname'];
        $date = date("Y-m-d", strtotime($req['date']));
        $address = $req['address'];

            try {
            $sql = "INSERT INTO `tbl_profile`
            VALUES (0,'$fname','$lname','$address' , '$date',1)";
                $con->exec($sql);
                 echo 'Added successfully';
            }
        catch(PDOException $e){
            echo $sql . "<br>" . $e->getMessage();
        }
    }
    function displayProfiles(){
        global $con;
        $sql = "SELECT * FROM `tbl_profile` ORDER BY id ";
        $stmt = $con->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_BOTH);
    }
    function viewProfile($id = 0){
        global $con;
        $sql = "SELECT * FROM tbl_profile WHERE id = $id";
        
        $stmt = $con->prepare($sql);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_BOTH);
    }
    function deleteProfile($id = 0){
        global $con;
        $sql = "DELETE FROM `tbl_profile` WHERE id = $id";
        
        $stmt = $con->prepare($sql);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_BOTH);
    }
    function updateProfile(){
        if (isset($_POST['btn'])) {
            
            global $con;
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $date = date("Y-m-d", strtotime($_POST['date']));
            $address = $_POST['address'];
        
            try {
                $pdo = new PDO('mysql:host=localhost;dbname=db_app', 'root', '');
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
                $sql = "UPDATE `tbl_profile` SET fname=:fname, lname=:lname, date=:date, address=:address WHERE id=:id";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':fname', $fname);
                $stmt->bindParam(':lname', $lname);
                $stmt->bindParam(':date', $date);
                $stmt->bindParam(':address', $address);
                $stmt->bindParam(':id', $id);
                $stmt->execute();
        
                echo "updated na!";
            } catch (PDOException $e) {
                echo "Error: " . $e->getMessage();
            }
        }
    }
}


?>