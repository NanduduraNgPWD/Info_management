<?php include('partials/header.php');
include('./classes/Profile.php');
$Profile = new Profile();
$profiles = $Profile->displayProfiles();
if(isset($_REQUEST['delid'])){
    $did = $_REQUEST['delid'];
   $Profile->deleteProfile($did); ?>
    <script>
        confirm("r u sure?")
    </script>
    <?php
    echo "DELETED";
    }
?>
<table border = '1' cellpadding="5">
    <tr>
    <th>ID</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Address</th>
    <th> Birthday</th>
    <th> Action </th>
    </tr>

        <?php foreach($profiles as $prof){ ?>
        <tr>
            <td><?php echo $prof['id'];?></td>
            <td>
<a href = "profile.php?id=<?php echo $prof['id']; ?>"><?php echo $prof['fname'];?> </a>
            </td>
            <td><?php echo $prof['lname'];?></td>
            <td><?php echo $prof['address'];?></td>
            <td><?php echo date("F d,Y" , strtotime($prof['date']));?></td>
            <td>
                <img src ='images/view.jpg' width = '16' >
                <a href="update.php?updateid=<?php echo $prof['id']; ?>"><img src="images/edit.png" width="16"></a>


                <a href= "view.php?delid=<?php echo $prof['id']; ?>"><img src ='images/delete.jpg' width = '16' ></a>
            </td>
        </tr>
         <?php } ?>


</table>

<?php include('partials/footer.php'); ?>